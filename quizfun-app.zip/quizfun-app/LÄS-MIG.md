# QuizFun – så lägger du ut appen på App Store

## Det här behöver du
- En **Mac** med **Xcode** (gratis i Mac App Store).
- Ett **Apple Developer-konto**, som kostar 99 USD per år: developer.apple.com/programs
  Kontot måste ägas av någon som är myndig (18+). Är du yngre kan en förälder skapa kontot och stå som utvecklare.
- **Node.js** (nodejs.org), som behövs för att bygga projektet.
- En iPhone att testa på (rekommenderas).

## 1. Förbered projektet (en gång)
Öppna Terminal i den här mappen och kör:

    npm install
    npx cap add ios
    npx capacitor-assets generate --ios --iconBackgroundColor '#060918'
    npm run ios

Nu öppnas Xcode.

Innan du går vidare, öppna `capacitor.config.json` och byt `se.dittnamn.quizfun` mot ett eget unikt ID, till exempel `se.dennis.quizfun`.

## 2. I Xcode
1. Klicka på **App** i vänsterlistan och välj fliken **Signing & Capabilities**.
2. Under **Team** väljer du ditt Apple Developer-konto.
3. Koppla in din iPhone, välj den högst upp och tryck ▶ för att testa.
4. Under **General** sätter du Version till `1.0` och Build till `1`.

## 3. Skapa appen i App Store Connect
1. Gå till appstoreconnect.apple.com, välj **Mina appar** och sedan **+ Ny app**.
2. Namn: QuizFun (om namnet är upptaget, testa till exempel "QuizFun: Quiz & Karaktärer").
3. Välj samma Bundle ID som i `capacitor.config.json`.
4. Fyll i:
   - **Kategori:** Spel → Trivia
   - **Åldersgräns:** fyll i frågorna. Spelet innehåller inget olämpligt, så det bör bli 4+.
   - **Integritet:** "Data samlas inte in". Appen sparar bara lokalt på telefonen.
   - **Integritetspolicy-URL:** krävs. En enkel gratis sida räcker.
   - **Skärmbilder:** minst 3 st från en iPhone med 6,7/6,9 tums skärm (ta dem i simulatorn med Cmd+S).
   - **Beskrivning** (finns nedan).

## 4. Ladda upp
1. I Xcode väljer du **Any iOS Device** och sedan **Product → Archive**.
2. Välj **Distribute App**, sedan **App Store Connect** och sedan **Upload**.
3. I App Store Connect väljer du bygget och trycker **Skicka för granskning**.
Granskningen tar oftast 1–3 dagar.

## Tips för att bli godkänd
Apple nekar ibland appar som känns för tunna eller bara är en webbsida (regel 4.2). Innan du skickar in:
- Lägg till fler frågor, minst 30–50 per kategori.
- Testa noga att allt funkar utan buggar.
- Typsnitten laddas från nätet. Utan internet används ett reservtypsnitt, men spelet funkar ändå.

## Förslag på App Store-text
**Undertitel:** Quiz, nivåer & din egen gubbe

**Beskrivning:**
Utmana dig själv i QuizFun! Svara rätt och snabbt i sex kategorier: Sport, Geografi, Historia, Vetenskap, Gaming och Sverige. Eller kör Blandat.

• 15 sekunder per fråga, snabba svar ger fler poäng
• Svitbonus upp till x3
• Livlinor: 50/50 och Hoppa över
• Samla stjärnor, gå upp i nivå och tjäna kristaller
• Skapa upp till 5 egna karaktärer: robotar, aliens, drakar och mer
• Lås upp auror, husdjur, hattar, glasögon och kläder

**Nyckelord:** quiz,frågesport,trivia,frågor,kunskap,sverige,spel,nivåer,karaktär
